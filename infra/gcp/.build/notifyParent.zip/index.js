"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// src/functions/notifyParent.ts
var notifyParent_exports = {};
__export(notifyParent_exports, {
  handleRequestCreated: () => handleRequestCreated,
  notifyParent: () => notifyParent
});
module.exports = __toCommonJS(notifyParent_exports);
var import_firestore3 = require("firebase-functions/v2/firestore");

// src/lib/log.ts
var import_v2 = require("firebase-functions/v2");
function logInfo(message, fields) {
  import_v2.logger.info(message, fields);
}
function logWarn(message, fields) {
  import_v2.logger.warn(message, fields);
}

// src/lib/notify.ts
var import_messaging = require("firebase-admin/messaging");

// src/lib/secureCallable.ts
var import_app = require("firebase-admin/app");
var import_firestore2 = require("firebase-admin/firestore");
var import_https2 = require("firebase-functions/v2/https");

// src/lib/rateLimit.ts
var import_https = require("firebase-functions/v2/https");
var import_firestore = require("firebase-admin/firestore");

// src/lib/secureCallable.ts
function defaultDb() {
  if ((0, import_app.getApps)().length === 0) (0, import_app.initializeApp)();
  return (0, import_firestore2.getFirestore)();
}

// src/lib/notify.ts
var BATCH = 500;
var TTL_MS = 60 * 60 * 1e3;
var MAX_LABEL = 40;
var DEAD_TOKEN_CODES = /* @__PURE__ */ new Set(["messaging/registration-token-not-registered", "messaging/invalid-registration-token"]);
var defaultNotifyDeps = { db: defaultDb, messaging: () => (0, import_messaging.getMessaging)() };
function cleanLabel(value, fallback) {
  if (typeof value !== "string") return fallback;
  const cleaned = value.replace(/[\p{Cc}\p{Cf}\p{Zl}\p{Zp}]/gu, " ").replace(/\s+/g, " ").trim();
  if (cleaned === "") return fallback;
  return Array.from(cleaned).slice(0, MAX_LABEL).join("");
}
async function pushToParent(deps, fn, parentUid, data) {
  const db = deps.db();
  const tokenCollection = db.collection("users").doc(parentUid).collection("fcmTokens");
  const tokens = (await tokenCollection.get()).docs.map((d) => d.id);
  let sent = 0;
  let pruned = 0;
  for (let i = 0; i < tokens.length; i += BATCH) {
    const batch = tokens.slice(i, i + BATCH);
    try {
      const response = await deps.messaging().sendEachForMulticast({
        tokens: batch,
        data,
        android: { priority: "high", ttl: TTL_MS }
      });
      const dead = [];
      response.responses.forEach((r, index) => {
        const token = batch[index];
        if (r.success) {
          sent += 1;
        } else if (token !== void 0 && DEAD_TOKEN_CODES.has(r.error?.code ?? "")) {
          dead.push(token);
        }
      });
      await Promise.all(dead.map((t) => tokenCollection.doc(t).delete()));
      pruned += dead.length;
    } catch {
      logWarn("push batch failed", { fn, outcome: "send-failed" });
    }
  }
  logInfo("push sent", { fn, outcome: `sent=${sent} pruned=${pruned} tokens=${tokens.length}` });
  return { sent, pruned };
}

// src/functions/notifyParent.ts
var MAX_MINUTES = 480;
async function handleRequestCreated(deps, event) {
  const { data } = event;
  const minutes = data?.minutes;
  if (data === void 0 || data.status !== "pending" || typeof minutes !== "number" || !Number.isInteger(minutes) || minutes < 1 || minutes > MAX_MINUTES) {
    logWarn("ignored a request document that does not fit", { fn: "notifyParent", outcome: "invalid-request" });
    return null;
  }
  const device = await deps.db().collection("users").doc(event.parentUid).collection("devices").doc(event.deviceId).get();
  if (!device.exists) return null;
  return pushToParent(deps, "notifyParent", event.parentUid, {
    type: "request",
    deviceId: event.deviceId,
    reqId: event.reqId,
    device: cleanLabel(device.get("name"), "Your child's phone"),
    app: cleanLabel(data.app, "an app"),
    minutes: String(minutes)
  });
}
var notifyParent = (0, import_firestore3.onDocumentCreated)(
  { document: "users/{uid}/devices/{deviceId}/requests/{reqId}", region: "europe-west1" },
  async (event) => {
    const { uid, deviceId, reqId } = event.params;
    await handleRequestCreated(defaultNotifyDeps, {
      parentUid: uid,
      deviceId,
      reqId,
      data: event.data?.data()
    });
  }
);
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handleRequestCreated,
  notifyParent
});
