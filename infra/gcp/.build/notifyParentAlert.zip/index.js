"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// src/functions/notifyParentAlert.ts
var notifyParentAlert_exports = {};
__export(notifyParentAlert_exports, {
  handleAlertCreated: () => handleAlertCreated,
  notifyParentAlert: () => notifyParentAlert
});
module.exports = __toCommonJS(notifyParentAlert_exports);
var import_firestore3 = require("firebase-admin/firestore");
var import_firestore4 = require("firebase-functions/v2/firestore");

// src/lib/log.ts
var import_v2 = require("firebase-functions/v2");
function logInfo(message, fields) {
  import_v2.logger.info(message, fields);
}
function logWarn(message, fields) {
  import_v2.logger.warn(message, fields);
}

// src/lib/notify.ts
var import_messaging = require("firebase-admin/messaging");

// src/lib/secureCallable.ts
var import_app = require("firebase-admin/app");
var import_firestore2 = require("firebase-admin/firestore");
var import_https2 = require("firebase-functions/v2/https");

// src/lib/rateLimit.ts
var import_https = require("firebase-functions/v2/https");
var import_firestore = require("firebase-admin/firestore");

// src/lib/secureCallable.ts
function defaultDb() {
  if ((0, import_app.getApps)().length === 0) (0, import_app.initializeApp)();
  return (0, import_firestore2.getFirestore)();
}

// src/lib/notify.ts
var BATCH = 500;
var TTL_MS = 60 * 60 * 1e3;
var MAX_LABEL = 40;
var DEAD_TOKEN_CODES = /* @__PURE__ */ new Set(["messaging/registration-token-not-registered", "messaging/invalid-registration-token"]);
var defaultNotifyDeps = { db: defaultDb, messaging: () => (0, import_messaging.getMessaging)() };
function cleanLabel(value, fallback) {
  if (typeof value !== "string") return fallback;
  const cleaned = value.replace(/[\p{Cc}\p{Cf}\p{Zl}\p{Zp}]/gu, " ").replace(/\s+/g, " ").trim();
  if (cleaned === "") return fallback;
  return Array.from(cleaned).slice(0, MAX_LABEL).join("");
}
async function pushToParent(deps, fn, parentUid, data) {
  const db = deps.db();
  const tokenCollection = db.collection("users").doc(parentUid).collection("fcmTokens");
  const tokens = (await tokenCollection.get()).docs.map((d) => d.id);
  let sent = 0;
  let pruned = 0;
  for (let i = 0; i < tokens.length; i += BATCH) {
    const batch = tokens.slice(i, i + BATCH);
    try {
      const response = await deps.messaging().sendEachForMulticast({
        tokens: batch,
        data,
        android: { priority: "high", ttl: TTL_MS }
      });
      const dead = [];
      response.responses.forEach((r, index) => {
        const token = batch[index];
        if (r.success) {
          sent += 1;
        } else if (token !== void 0 && DEAD_TOKEN_CODES.has(r.error?.code ?? "")) {
          dead.push(token);
        }
      });
      await Promise.all(dead.map((t) => tokenCollection.doc(t).delete()));
      pruned += dead.length;
    } catch {
      logWarn("push batch failed", { fn, outcome: "send-failed" });
    }
  }
  logInfo("push sent", { fn, outcome: `sent=${sent} pruned=${pruned} tokens=${tokens.length}` });
  return { sent, pruned };
}

// src/functions/notifyParentAlert.ts
var MAX_ALERTS_PER_PERMISSION = 3;
var WINDOW_MS = 10 * 60 * 1e3;
var WINDOW_READ_LIMIT = 40;
var KNOWN_PERMISSIONS = /* @__PURE__ */ new Set(["accessibility", "usage", "overlay", "notifications"]);
async function handleAlertCreated(deps, event) {
  const { data } = event;
  if (data === void 0 || data.kind !== "permission_lost" || data.dismissed !== false) {
    logWarn("ignored an alert document that is not announced", { fn: "notifyParentAlert", outcome: "not-announced" });
    return null;
  }
  const deviceRef = deps.db().collection("users").doc(event.parentUid).collection("devices").doc(event.deviceId);
  const device = await deviceRef.get();
  if (!device.exists) return null;
  const current = await deviceRef.collection("alerts").doc(event.alertId).get();
  if (!current.exists || current.get("dismissed") !== false) return null;
  const raw = typeof data.permission === "string" ? data.permission.toLowerCase() : "";
  const permission = KNOWN_PERMISSIONS.has(raw) ? raw : "other";
  const recent = await deviceRef.collection("alerts").where("createdAt", ">=", import_firestore3.Timestamp.fromMillis(Date.now() - WINDOW_MS)).limit(WINDOW_READ_LIMIT).get();
  const sameKind = recent.docs.filter((d) => {
    const p = d.get("permission");
    const name = typeof p === "string" ? p.toLowerCase() : "";
    return d.get("kind") === "permission_lost" && (KNOWN_PERMISSIONS.has(name) ? name : "other") === permission;
  });
  if (sameKind.length > MAX_ALERTS_PER_PERMISSION) {
    logWarn("too many alerts for one permission; push skipped", { fn: "notifyParentAlert", outcome: "rate-limited" });
    return null;
  }
  return pushToParent(deps, "notifyParentAlert", event.parentUid, {
    type: "alert",
    deviceId: event.deviceId,
    alertId: event.alertId,
    device: cleanLabel(device.get("name"), "Your child's phone"),
    permission
  });
}
var notifyParentAlert = (0, import_firestore4.onDocumentCreated)(
  { document: "users/{uid}/devices/{deviceId}/alerts/{alertId}", region: "europe-west1" },
  async (event) => {
    const { uid, deviceId, alertId } = event.params;
    await handleAlertCreated(defaultNotifyDeps, { parentUid: uid, deviceId, alertId, data: event.data?.data() });
  }
);
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handleAlertCreated,
  notifyParentAlert
});
